from selenium import webdriver
from selenium.webdriver.common.keys import Keys 
import Pageobjects.Twitter_authentication as authentication

class Instagram():
    def __init__(self):
        self.authentication = authentication.Authentication()