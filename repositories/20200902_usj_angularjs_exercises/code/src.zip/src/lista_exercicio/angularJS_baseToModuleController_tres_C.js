app.controller("meuController2", function ($scope) {
    $scope.firstName = "jorge";
    $scope.lastName = "Marina";
});