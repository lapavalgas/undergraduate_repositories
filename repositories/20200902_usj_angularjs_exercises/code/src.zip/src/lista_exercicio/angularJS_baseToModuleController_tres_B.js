app.controller("meuController", function ($scope) {
    $scope.firstName = "Carla";
    $scope.lastName = "Sabrina";
});