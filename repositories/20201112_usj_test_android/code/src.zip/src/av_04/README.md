4. Escreva um algoritmo em JAVA ANDROID STUDIO para ler o salário mensal atual de um funcionário e o
percentual de reajuste.
Calcular e escrever o valor do novo salário.