1. Escreva um algoritmo em JAVA ANDROID STUDIO para ler um valor e escrever apresentar o seu
antecessor.