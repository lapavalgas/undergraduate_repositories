2. Escreva um algoritmo em JAVA ANDROID STUDIO para ler as dimensões de um retângulo (base e
altura), calcular e escrever a área do retângulo.