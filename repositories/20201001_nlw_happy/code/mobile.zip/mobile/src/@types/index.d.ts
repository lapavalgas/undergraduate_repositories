// arquivo de definições de tipos do typescript para o projeto

declare module '*.png';