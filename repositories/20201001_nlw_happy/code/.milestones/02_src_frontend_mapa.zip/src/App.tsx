import React from 'react';
import './pages/global.css';
import Routes from './routes';

function App() {
  return (
    <Routes />
  );
}

export default App;
